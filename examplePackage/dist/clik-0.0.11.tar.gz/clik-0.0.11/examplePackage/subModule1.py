def printThis(string):
    print(string)