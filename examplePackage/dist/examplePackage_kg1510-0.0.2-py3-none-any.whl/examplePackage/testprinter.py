from oneMoreScript import printer
def examplefunction(str1):
    print(str1)

examplefunction("hellooo")
s = input("Enter your name: ")
printer(s)
