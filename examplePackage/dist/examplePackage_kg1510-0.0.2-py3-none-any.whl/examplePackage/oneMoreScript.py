import pyfiglet
def printer(namee):
    result = pyfiglet.figlet_format(namee)
    print(result)