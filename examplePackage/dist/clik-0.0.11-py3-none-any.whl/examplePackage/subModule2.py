from examplePackage.subModule1 import printThis

def printThis2(string):
    printThis(string)