from examplePackage.oneMoreScript import printThis

def printThis2(string):
    printThis(string)